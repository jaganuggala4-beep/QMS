/**
 * QMS Database Layer - Permanent localStorage-based store
 * Simulates SQLite persistence across sessions
 * Data NEVER resets unless admin explicitly deletes it
 */

// ======================== TYPE DEFINITIONS ========================

export type UserRole = 'admin' | 'qc' | 'agent';
export type AgentSubtype = 'COLLECTION' | 'REVERIFICATION' | 'CUSTOMER_CARE' | 'MAILS';
export type ScoringType = '1-10' | 'YES_NO_NA';
export type DisputeStatus = 'PENDING' | 'RESOLVED' | 'REJECTED';
export type TemplateType = 'CALL' | 'MAIL';

export interface User {
  id: string;
  username: string;
  password: string; // stored hashed-like (base64 for demo)
  role: UserRole;
  subtype?: AgentSubtype; // for agents
  fullName: string;
  email: string;
  createdAt: string;
  isActive: boolean;
}

export interface TemplateParameter {
  id: string;
  name: string;
  scoringType: ScoringType;
  weightage: number; // percentage
}

export interface Template {
  id: string;
  name: string;
  type: TemplateType;
  parameters: TemplateParameter[];
  createdAt: string;
  createdBy: string; // admin user id
  isActive: boolean;
}

export interface Allocation {
  id: string;
  qcId: string;
  agentId: string;
  createdAt: string;
  assignedBy: string; // admin user id
}

export interface AuditScore {
  parameterId: string;
  parameterName: string;
  scoringType: ScoringType;
  weightage: number;
  givenScore: number | string; // 0-10 or YES/NO/NA
  calculatedScore: number; // computed score
}

export interface Audit {
  id: string;
  agentId: string;
  qcId: string;
  templateId: string;
  templateName: string;
  templateType: TemplateType;
  referenceNumber: string;
  callRecording?: string; // filename
  duration?: string; // for CALL type
  conversationDate: string;
  scores: AuditScore[];
  totalScore: number; // calculated server-side only
  maxPossibleScore: number;
  percentageScore: number;
  feedback: string;
  createdAt: string;
  updatedAt: string;
  isReAudit: boolean;
  originalAuditId?: string;
}

export interface Dispute {
  id: string;
  auditId: string;
  agentId: string;
  qcId: string;
  reason: string;
  status: DisputeStatus;
  resolution?: string;
  createdAt: string;
  resolvedAt?: string;
  resolvedBy?: string;
}

// ======================== DB KEYS ========================
const KEYS = {
  USERS: 'qms_users',
  TEMPLATES: 'qms_templates',
  ALLOCATIONS: 'qms_allocations',
  AUDITS: 'qms_audits',
  DISPUTES: 'qms_disputes',
  INITIALIZED: 'qms_initialized',
};

// ======================== HELPERS ========================
function generateId(): string {
  return Date.now().toString(36) + Math.random().toString(36).substr(2, 9);
}

function hashPassword(password: string): string {
  // Simple encoding for demo - in production use bcrypt
  return btoa(password + '_qms_salt');
}

function verifyPassword(password: string, hash: string): boolean {
  return btoa(password + '_qms_salt') === hash;
}

// ======================== GENERIC CRUD ========================
function getAll<T>(key: string): T[] {
  try {
    const data = localStorage.getItem(key);
    return data ? JSON.parse(data) : [];
  } catch {
    return [];
  }
}

function saveAll<T>(key: string, data: T[]): void {
  localStorage.setItem(key, JSON.stringify(data));
}

// ======================== INITIALIZATION ========================
export function initializeDatabase(): void {
  const initialized = localStorage.getItem(KEYS.INITIALIZED);
  if (initialized) return; // Never reinitialize if data exists

  // Create default admin user
  const adminUser: User = {
    id: 'admin_001',
    username: 'admin',
    password: hashPassword('admin123'),
    role: 'admin',
    fullName: 'System Administrator',
    email: 'admin@qms.com',
    createdAt: new Date().toISOString(),
    isActive: true,
  };

  // Create sample QC
  const qcUser: User = {
    id: 'qc_001',
    username: 'qc1',
    password: hashPassword('qc123'),
    role: 'qc',
    fullName: 'Quality Controller One',
    email: 'qc1@qms.com',
    createdAt: new Date().toISOString(),
    isActive: true,
  };

  // Create sample agents
  const agents: User[] = [
    {
      id: 'agent_001',
      username: 'agent_col1',
      password: hashPassword('agent123'),
      role: 'agent',
      subtype: 'COLLECTION',
      fullName: 'Alex Collection',
      email: 'alex@qms.com',
      createdAt: new Date().toISOString(),
      isActive: true,
    },
    {
      id: 'agent_002',
      username: 'agent_rev1',
      password: hashPassword('agent123'),
      role: 'agent',
      subtype: 'REVERIFICATION',
      fullName: 'Sam Reverification',
      email: 'sam@qms.com',
      createdAt: new Date().toISOString(),
      isActive: true,
    },
    {
      id: 'agent_003',
      username: 'agent_cc1',
      password: hashPassword('agent123'),
      role: 'agent',
      subtype: 'CUSTOMER_CARE',
      fullName: 'Jordan CustomerCare',
      email: 'jordan@qms.com',
      createdAt: new Date().toISOString(),
      isActive: true,
    },
    {
      id: 'agent_004',
      username: 'agent_mail1',
      password: hashPassword('agent123'),
      role: 'agent',
      subtype: 'MAILS',
      fullName: 'Casey Mails',
      email: 'casey@qms.com',
      createdAt: new Date().toISOString(),
      isActive: true,
    },
  ];

  // Create sample template
  const callTemplate: Template = {
    id: 'tmpl_001',
    name: 'Call Quality Template v1',
    type: 'CALL',
    parameters: [
      { id: 'p1', name: 'Opening Greeting', scoringType: '1-10', weightage: 10 },
      { id: 'p2', name: 'Call Compliance', scoringType: 'YES_NO_NA', weightage: 20 },
      { id: 'p3', name: 'Communication Skills', scoringType: '1-10', weightage: 25 },
      { id: 'p4', name: 'Problem Resolution', scoringType: '1-10', weightage: 30 },
      { id: 'p5', name: 'Closing Statement', scoringType: 'YES_NO_NA', weightage: 15 },
    ],
    createdAt: new Date().toISOString(),
    createdBy: 'admin_001',
    isActive: true,
  };

  const mailTemplate: Template = {
    id: 'tmpl_002',
    name: 'Mail Quality Template v1',
    type: 'MAIL',
    parameters: [
      { id: 'p6', name: 'Subject Line Quality', scoringType: '1-10', weightage: 15 },
      { id: 'p7', name: 'Grammar & Spelling', scoringType: '1-10', weightage: 20 },
      { id: 'p8', name: 'Content Accuracy', scoringType: 'YES_NO_NA', weightage: 30 },
      { id: 'p9', name: 'Response Completeness', scoringType: '1-10', weightage: 35 },
    ],
    createdAt: new Date().toISOString(),
    createdBy: 'admin_001',
    isActive: true,
  };

  // Create sample allocation
  const allocation: Allocation = {
    id: 'alloc_001',
    qcId: 'qc_001',
    agentId: 'agent_001',
    createdAt: new Date().toISOString(),
    assignedBy: 'admin_001',
  };
  const allocation2: Allocation = {
    id: 'alloc_002',
    qcId: 'qc_001',
    agentId: 'agent_002',
    createdAt: new Date().toISOString(),
    assignedBy: 'admin_001',
  };

  saveAll(KEYS.USERS, [adminUser, qcUser, ...agents]);
  saveAll(KEYS.TEMPLATES, [callTemplate, mailTemplate]);
  saveAll(KEYS.ALLOCATIONS, [allocation, allocation2]);
  saveAll(KEYS.AUDITS, []);
  saveAll(KEYS.DISPUTES, []);
  localStorage.setItem(KEYS.INITIALIZED, 'true');
}

// ======================== USER OPERATIONS ========================
export const UserDB = {
  getAll(): User[] {
    return getAll<User>(KEYS.USERS);
  },

  getById(id: string): User | undefined {
    return this.getAll().find(u => u.id === id);
  },

  getByUsername(username: string): User | undefined {
    return this.getAll().find(u => u.username.toLowerCase() === username.toLowerCase());
  },

  authenticate(username: string, password: string): User | null {
    const user = this.getByUsername(username);
    if (!user || !user.isActive) return null;
    if (verifyPassword(password, user.password)) return user;
    return null;
  },

  create(data: Omit<User, 'id' | 'createdAt' | 'password'> & { password: string }): User {
    const users = this.getAll();
    const newUser: User = {
      ...data,
      id: generateId(),
      password: hashPassword(data.password),
      createdAt: new Date().toISOString(),
    };
    users.push(newUser);
    saveAll(KEYS.USERS, users);
    return newUser;
  },

  delete(id: string): void {
    const users = this.getAll().filter(u => u.id !== id && u.role !== 'admin');
    saveAll(KEYS.USERS, users.filter(u => u.id !== id));
  },

  update(id: string, data: Partial<User>): void {
    const users = this.getAll().map(u => (u.id === id ? { ...u, ...data } : u));
    saveAll(KEYS.USERS, users);
  },

  getByRole(role: UserRole): User[] {
    return this.getAll().filter(u => u.role === role);
  },

  getAgentsBySubtype(subtype: AgentSubtype): User[] {
    return this.getAll().filter(u => u.role === 'agent' && u.subtype === subtype);
  },
};

// ======================== TEMPLATE OPERATIONS ========================
export const TemplateDB = {
  getAll(): Template[] {
    return getAll<Template>(KEYS.TEMPLATES);
  },

  getById(id: string): Template | undefined {
    return this.getAll().find(t => t.id === id);
  },

  create(data: Omit<Template, 'id' | 'createdAt'>): Template {
    const templates = this.getAll();
    const newTemplate: Template = {
      ...data,
      id: generateId(),
      createdAt: new Date().toISOString(),
    };
    templates.push(newTemplate);
    saveAll(KEYS.TEMPLATES, templates);
    return newTemplate;
  },

  update(id: string, data: Partial<Template>): void {
    const templates = this.getAll().map(t => (t.id === id ? { ...t, ...data } : t));
    saveAll(KEYS.TEMPLATES, templates);
  },

  delete(id: string): void {
    const templates = this.getAll().filter(t => t.id !== id);
    saveAll(KEYS.TEMPLATES, templates);
  },
};

// ======================== ALLOCATION OPERATIONS ========================
export const AllocationDB = {
  getAll(): Allocation[] {
    return getAll<Allocation>(KEYS.ALLOCATIONS);
  },

  allocate(qcId: string, agentId: string, assignedBy: string): Allocation {
    const existing = this.getAll().find(a => a.qcId === qcId && a.agentId === agentId);
    if (existing) return existing;

    const allocations = this.getAll();
    const newAlloc: Allocation = {
      id: generateId(),
      qcId,
      agentId,
      createdAt: new Date().toISOString(),
      assignedBy,
    };
    allocations.push(newAlloc);
    saveAll(KEYS.ALLOCATIONS, allocations);
    return newAlloc;
  },

  deallocate(qcId: string, agentId: string): void {
    const allocations = this.getAll().filter(a => !(a.qcId === qcId && a.agentId === agentId));
    saveAll(KEYS.ALLOCATIONS, allocations);
  },

  getAgentsForQC(qcId: string): string[] {
    return this.getAll().filter(a => a.qcId === qcId).map(a => a.agentId);
  },

  getQCForAgent(agentId: string): string[] {
    return this.getAll().filter(a => a.agentId === agentId).map(a => a.qcId);
  },

  isAllocated(qcId: string, agentId: string): boolean {
    return this.getAll().some(a => a.qcId === qcId && a.agentId === agentId);
  },
};

// ======================== SCORING ENGINE ========================
export function calculateAuditScore(
  parameters: TemplateParameter[],
  scores: { parameterId: string; givenScore: number | string }[]
): { scores: AuditScore[]; totalScore: number; maxPossibleScore: number; percentageScore: number } {
  let totalWeightageUsed = 0;
  let totalScore = 0;

  const auditScores: AuditScore[] = parameters.map(param => {
    const scoreEntry = scores.find(s => s.parameterId === param.id);
    const given = scoreEntry?.givenScore;
    let calculated = 0;
    let includeInTotal = true;

    if (param.scoringType === '1-10') {
      const numScore = Number(given) || 0;
      calculated = (numScore / 10) * param.weightage;
      totalWeightageUsed += param.weightage;
    } else {
      // YES_NO_NA
      if (given === 'YES') {
        calculated = param.weightage;
        totalWeightageUsed += param.weightage;
      } else if (given === 'NO') {
        calculated = 0;
        totalWeightageUsed += param.weightage;
      } else {
        // NA - excluded from scoring
        calculated = 0;
        includeInTotal = false;
      }
    }

    if (includeInTotal) totalScore += calculated;

    return {
      parameterId: param.id,
      parameterName: param.name,
      scoringType: param.scoringType,
      weightage: param.weightage,
      givenScore: given ?? (param.scoringType === '1-10' ? 0 : 'NA'),
      calculatedScore: parseFloat(calculated.toFixed(2)),
    };
  });

  const percentageScore = totalWeightageUsed > 0 ? (totalScore / totalWeightageUsed) * 100 : 0;

  return {
    scores: auditScores,
    totalScore: parseFloat(totalScore.toFixed(2)),
    maxPossibleScore: totalWeightageUsed,
    percentageScore: parseFloat(percentageScore.toFixed(2)),
  };
}

// ======================== AUDIT OPERATIONS ========================
export const AuditDB = {
  getAll(): Audit[] {
    return getAll<Audit>(KEYS.AUDITS);
  },

  getById(id: string): Audit | undefined {
    return this.getAll().find(a => a.id === id);
  },

  getByAgent(agentId: string): Audit[] {
    return this.getAll().filter(a => a.agentId === agentId);
  },

  getByQC(qcId: string): Audit[] {
    return this.getAll().filter(a => a.qcId === qcId);
  },

  searchByReference(refNum: string): Audit[] {
    return this.getAll().filter(a =>
      a.referenceNumber.toLowerCase().includes(refNum.toLowerCase())
    );
  },

  create(data: Omit<Audit, 'id' | 'createdAt' | 'updatedAt'>): Audit {
    const audits = this.getAll();
    const newAudit: Audit = {
      ...data,
      id: generateId(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    audits.push(newAudit);
    saveAll(KEYS.AUDITS, audits);
    return newAudit;
  },

  update(id: string, data: Partial<Audit>): void {
    const audits = this.getAll().map(a =>
      a.id === id ? { ...a, ...data, updatedAt: new Date().toISOString() } : a
    );
    saveAll(KEYS.AUDITS, audits);
  },

  delete(id: string): void {
    const audits = this.getAll().filter(a => a.id !== id);
    saveAll(KEYS.AUDITS, audits);
  },

  getFiltered(filters: {
    fromDate?: string;
    toDate?: string;
    agentId?: string;
    qcId?: string;
    subtype?: AgentSubtype;
  }): Audit[] {
    let audits = this.getAll();

    if (filters.fromDate) {
      audits = audits.filter(a => new Date(a.conversationDate) >= new Date(filters.fromDate!));
    }
    if (filters.toDate) {
      audits = audits.filter(a => new Date(a.conversationDate) <= new Date(filters.toDate!));
    }
    if (filters.agentId) {
      audits = audits.filter(a => a.agentId === filters.agentId);
    }
    if (filters.qcId) {
      audits = audits.filter(a => a.qcId === filters.qcId);
    }
    if (filters.subtype) {
      const agents = UserDB.getAgentsBySubtype(filters.subtype).map(u => u.id);
      audits = audits.filter(a => agents.includes(a.agentId));
    }

    return audits;
  },
};

// ======================== DISPUTE OPERATIONS ========================
export const DisputeDB = {
  getAll(): Dispute[] {
    return getAll<Dispute>(KEYS.DISPUTES);
  },

  getById(id: string): Dispute | undefined {
    return this.getAll().find(d => d.id === id);
  },

  getByAudit(auditId: string): Dispute[] {
    return this.getAll().filter(d => d.auditId === auditId);
  },

  getByAgent(agentId: string): Dispute[] {
    return this.getAll().filter(d => d.agentId === agentId);
  },

  getByQC(qcId: string): Dispute[] {
    return this.getAll().filter(d => d.qcId === qcId);
  },

  getPending(): Dispute[] {
    return this.getAll().filter(d => d.status === 'PENDING');
  },

  create(data: Omit<Dispute, 'id' | 'createdAt' | 'status'>): Dispute {
    const disputes = this.getAll();
    const newDispute: Dispute = {
      ...data,
      id: generateId(),
      status: 'PENDING',
      createdAt: new Date().toISOString(),
    };
    disputes.push(newDispute);
    saveAll(KEYS.DISPUTES, disputes);
    return newDispute;
  },

  resolve(id: string, resolution: string, resolvedBy: string, status: 'RESOLVED' | 'REJECTED'): void {
    const disputes = this.getAll().map(d =>
      d.id === id
        ? { ...d, status, resolution, resolvedAt: new Date().toISOString(), resolvedBy }
        : d
    );
    saveAll(KEYS.DISPUTES, disputes);
  },
};

// ======================== PARETO ANALYSIS ========================
export interface ParetoItem {
  name: string;
  failCount: number;
  percentage: number;
  cumulativePercentage: number;
}

export function calculateParameterPareto(audits: Audit[]): ParetoItem[] {
  const failMap: Record<string, number> = {};

  audits.forEach(audit => {
    audit.scores.forEach(score => {
      if (score.scoringType === 'YES_NO_NA' && score.givenScore === 'NO') {
        failMap[score.parameterName] = (failMap[score.parameterName] || 0) + 1;
      } else if (score.scoringType === '1-10' && Number(score.givenScore) < 5) {
        failMap[score.parameterName] = (failMap[score.parameterName] || 0) + 1;
      }
    });
  });

  const total = Object.values(failMap).reduce((a, b) => a + b, 0);
  const sorted = Object.entries(failMap)
    .sort(([, a], [, b]) => b - a)
    .map(([name, count]) => ({ name, failCount: count, percentage: total > 0 ? (count / total) * 100 : 0 }));

  let cumulative = 0;
  return sorted.map(item => {
    cumulative += item.percentage;
    return { ...item, cumulativePercentage: parseFloat(cumulative.toFixed(2)), percentage: parseFloat(item.percentage.toFixed(2)) };
  });
}

// ======================== EXCEL EXPORT ========================
export function generateExcelReport(
  reportType: string,
  audits: Audit[],
  users: User[]
): void {
  import('xlsx').then(XLSX => {
    const wb = XLSX.utils.book_new();

    const getUserName = (id: string) => users.find(u => u.id === id)?.fullName || id;

    if (reportType === 'overall') {
      const data = audits.map(a => ({
        'Audit ID': a.id,
        'Reference Number': a.referenceNumber,
        'Agent': getUserName(a.agentId),
        'QC Officer': getUserName(a.qcId),
        'Template': a.templateName,
        'Type': a.templateType,
        'Conversation Date': a.conversationDate,
        'Total Score': a.totalScore,
        'Max Score': a.maxPossibleScore,
        'Percentage Score': a.percentageScore + '%',
        'Feedback': a.feedback,
        'Audit Date': new Date(a.createdAt).toLocaleDateString(),
      }));
      const ws = XLSX.utils.json_to_sheet(data);
      XLSX.utils.book_append_sheet(wb, ws, 'Overall Audit Report');
    }

    if (reportType === 'agent_wise' || reportType === 'overall') {
      const agentMap: Record<string, { total: number; count: number; scores: number[] }> = {};
      audits.forEach(a => {
        if (!agentMap[a.agentId]) agentMap[a.agentId] = { total: 0, count: 0, scores: [] };
        agentMap[a.agentId].total += a.percentageScore;
        agentMap[a.agentId].count += 1;
        agentMap[a.agentId].scores.push(a.percentageScore);
      });
      const data = Object.entries(agentMap).map(([id, val]) => ({
        'Agent': getUserName(id),
        'Total Audits': val.count,
        'Average Score': (val.total / val.count).toFixed(2) + '%',
        'Min Score': Math.min(...val.scores).toFixed(2) + '%',
        'Max Score': Math.max(...val.scores).toFixed(2) + '%',
      }));
      const ws = XLSX.utils.json_to_sheet(data);
      XLSX.utils.book_append_sheet(wb, ws, 'Agent Wise Report');
    }

    if (reportType === 'parameter_wise' || reportType === 'overall') {
      const paramMap: Record<string, { scores: number[]; yesCount: number; noCount: number; naCount: number }> = {};
      audits.forEach(a => {
        a.scores.forEach(s => {
          if (!paramMap[s.parameterName]) paramMap[s.parameterName] = { scores: [], yesCount: 0, noCount: 0, naCount: 0 };
          if (s.scoringType === '1-10') {
            paramMap[s.parameterName].scores.push(Number(s.givenScore));
          } else {
            if (s.givenScore === 'YES') paramMap[s.parameterName].yesCount++;
            else if (s.givenScore === 'NO') paramMap[s.parameterName].noCount++;
            else paramMap[s.parameterName].naCount++;
          }
        });
      });
      const data = Object.entries(paramMap).map(([name, val]) => ({
        'Parameter': name,
        'Avg Score (1-10)': val.scores.length > 0 ? (val.scores.reduce((a, b) => a + b, 0) / val.scores.length).toFixed(2) : 'N/A',
        'YES Count': val.yesCount || 'N/A',
        'NO Count': val.noCount || 'N/A',
        'NA Count': val.naCount || 'N/A',
        'Total Occurrences': val.scores.length + val.yesCount + val.noCount + val.naCount,
      }));
      const ws = XLSX.utils.json_to_sheet(data);
      XLSX.utils.book_append_sheet(wb, ws, 'Parameter Wise Report');
    }

    if (reportType === 'pareto' || reportType === 'overall') {
      const paretoData = calculateParameterPareto(audits);
      const data = paretoData.map(p => ({
        'Parameter': p.name,
        'Fail Count': p.failCount,
        'Percentage': p.percentage + '%',
        'Cumulative %': p.cumulativePercentage + '%',
      }));
      const ws = XLSX.utils.json_to_sheet(data);
      XLSX.utils.book_append_sheet(wb, ws, 'Pareto Analysis');
    }

    XLSX.writeFile(wb, `QMS_Report_${reportType}_${new Date().toISOString().split('T')[0]}.xlsx`);
  });
}
